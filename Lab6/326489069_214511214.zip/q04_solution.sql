
SELECT COUNT(ToyName) FROM Toys WHERE ToyName LIKE '%puzzle%';