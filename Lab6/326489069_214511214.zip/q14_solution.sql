
SELECT Manager FROM Shops WHERE Manager LIKE 'd%';