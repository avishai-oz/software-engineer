
SELECT (SUM(TodayRevenue) / COUNT(TodayRevenue)) FROM Shops;