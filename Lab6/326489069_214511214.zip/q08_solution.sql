
SELECT Name, Manager, TodayRevenue FROM Shops;