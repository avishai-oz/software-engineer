
SELECT (SUM(Price) / COUNT(Price)) FROM Toys;
