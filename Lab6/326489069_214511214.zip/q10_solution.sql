
SELECT Name, Address FROM Shops;