
SELECT Name FROM Shops ORDER BY TodayRevenue DESC;