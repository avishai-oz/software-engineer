
SELECT Name FROM Shops WHERE Manager = 'Netta Cohen';