
SELECT Manager FROM Shops WHERE TodayRevenue >= 10000;