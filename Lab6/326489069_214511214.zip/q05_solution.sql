
SELECT SUM(TodayRevenue) FROM Shops;